PIERCE SENSI — PROJETO ANDROID (WebView)

O que é:
Este projeto empacota o HTML corrigido da Pierce Sensi dentro de um aplicativo Android simples. A interface roda localmente no aparelho; não precisa de site para abrir.

IMPORTANTE:
- Este ZIP é o PROJETO-FONTE Android, não é um APK compilado.
- O ambiente onde foi preparado não possui o Android SDK/Gradle configurado para compilar e assinar um APK.
- Os dados que o HTML grava em armazenamento local continuam no aparelho e não são sincronizados com a nuvem.

Para gerar APK:
1. Abra/import o diretório PierceSensi em Android Studio ou em uma IDE Android compatível com projetos Gradle.
2. Permita que a IDE baixe os componentes Android SDK/Gradle necessários.
3. Aguarde a sincronização do Gradle.
4. Use Build > Build APK(s) (ou o comando equivalente da IDE).
5. Instale o APK de debug gerado em app/build/outputs/apk/debug/app-debug.apk.

Configuração:
- Nome: PIERCE SENSI
- Pacote: com.piercesensi.app
- Versão: 1.0
- Min SDK: Android 6.0 (API 23)
- Tela: retrato
- HTML original: app/src/main/assets/index.html

Se alterar o HTML, substitua o arquivo assets/index.html e compile novamente.


GERAR O APK PELO CELULAR (SEM INSTALAR COMPILADOR)
O projeto inclui um fluxo de compilação na nuvem pelo GitHub Actions.
1. Extraia o ZIP e crie um repositório no GitHub.
2. Envie TODOS os arquivos que estão dentro da pasta PierceSensiAndroid para a raiz do repositório (incluindo a pasta oculta .github).
3. Abra a aba Actions do repositório e selecione "Gerar APK Pierce Sensi".
4. Toque em "Run workflow" se não iniciou sozinho.
5. Quando terminar com sucesso, abra a execução e baixe o artefato "Pierce-Sensi-APK".
6. Extraia o artefato baixado; dentro estará app-debug.apk. Abra no Android para instalar.
A compilação acontece nos servidores do GitHub; este ZIP ainda NÃO contém o APK pronto.
Se o GitHub mostrar erro, envie uma captura da tela para corrigirmos.
